namespace TrabajoN1.Models;

public class Cliente
{
    public int Id { get; set; }
    public String? Nombre { get; set; }
    public String? Apellido { get; set; }
    public int Edad { get; set; }
    public string? Frecuencia { get; set; } 
    public int Anios { get; set; }

}